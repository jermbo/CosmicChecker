"use strict";

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

var megamanCharacters;
var selectedTextDisplay;

function init() {
  megamanCharacters = _toConsumableArray(document.querySelectorAll(".character"));
  selectedTextDisplay = document.querySelector(".selected-display");

  if (megamanCharacters.length == 0 || !selectedTextDisplay) {
    console.error("There are no megamanCharacters or text to interact with. Try building the HTML out a bit more.");
    return;
  }

  megamanCharacters.forEach(function (character) {
    character.addEventListener("click", selectCharacter);
  });
}

function selectCharacter(e) {
  e.preventDefault();
  megamanCharacters.forEach(function (c) {
    return c.classList.remove("selected");
  });
  e.target.classList.add("selected");
  selectedTextDisplay.innerText = e.target.innerText;
}

init();