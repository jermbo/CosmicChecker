"use strict";

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { if (!(Symbol.iterator in Object(arr) || Object.prototype.toString.call(arr) === "[object Arguments]")) { return; } var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

var Checker = function () {
  var version = "0.9.1";
  var body = document.querySelector("body");
  var wrapper = document.querySelector(".wrapper");
  var styles = document.styleSheets;
  var interfaceStyles = document.createElement("style");
  var currentIndex, allTasks, statusBox, instructionsBox, prev, next;
  init();

  function getVersion() {
    return version;
  }

  function init() {
    setUIStyles();
    currentIndex = 0;
    createInstructions();
  }

  function setUIStyles() {
    document.body.appendChild(interfaceStyles);
    interfaceStyles.innerHTML += "*{ box-sizing: border-box; }\n      .completed{ color: #004225; text-decoration: line-through; }\n      .completed:after{ content: '\\2713'; display: inline-block; margin-left: 5px; }\n      .instructionsBox p, .instructionsBox ul{ margin: 0; color: #0d0d0d; }\n      .instructionsBox li{ cursor: help; margin-bottom: 5px; }";
    interfaceStyles.innerHTML += ".instructionsBox {\n        background: #e5e5e5;\n        font-family: Arial;\n        box-shadow: inset 5px 0 10px rgba(0,0,0,0.5);\n        padding: 1vw;\n        opacity: 0.75;\n        position: fixed;\n        bottom: 0;\n        left: 0;\n        top: 0;\n        width: 35vw;\n        min-width: 250px;\n        overflow-x: auto;\n      }";
    interfaceStyles.innerHTML += ".wrapper {\n        position: absolute;\n        left: 35vw;\n        width: 65vw;\n      }"; // console.log(interfaceStyles);
  }

  function checkUserProgress() {
    var previousCompleted = allTasks[currentIndex].tasks.every(function (task) {
      return task.completed;
    });
    console.log("currentIndex ".concat(currentIndex, " ::: previousCompleted ").concat(previousCompleted));

    if (previousCompleted) {
      currentIndex++;

      if (currentIndex >= allTasks.length) {
        console.log("ALL DONE");
        return;
      }

      runTests();
    }
  }

  function loadTests(tasks) {
    console.log(tasks);

    if (!tasks || tasks.length < 1) {
      console.error("Please load tasks to complete");
      return;
    }

    allTasks = tasks;
    runTests();
  }

  function runTests() {
    allTasks[currentIndex].tasks.forEach(function (task) {
      task.completed = false;

      switch (task.type) {
        case "attribute":
          testAttribute(task);
          break;

        case "children":
          testChildren(task);
          break;

        case "element":
          testElement(task);
          break;

        case "externalStyles":
          testExternalStyles(task);
          break;

        case "inlineStyles":
          testInlineStyles(task);
          break;
      }
    });
    updateInstructions();
    checkUserProgress();
  }

  function testAttribute(obj) {
    var element = wrapper.querySelector(obj.el);
    if (!element) return;
    var attr = obj.test.item;
    var reg = new RegExp(obj.test.value, "gi");

    if (element[attr].match(reg)) {
      console.log("Added correct ".concat(attr, " to ").concat(obj.el));
      obj.completed = true;
      return;
    } // Check for any text as the innerText


    if (obj.test.value == "anything" && element[attr] != "") {
      console.log("Added a message of \"".concat(element[attr], "\" to ").concat(obj.el));
      obj.completed = true;
      return;
    }
  }

  function testChildren(obj) {
    var element = obj.el != "" ? wrapper.querySelector(obj.el) : wrapper;
    if (!element) return;

    var children = _toConsumableArray(element.children);

    var total = 0;

    for (var i = 0; i < children.length; i++) {
      if (children[i].localName != undefined && children[i].localName == obj.test.item) {
        total++;

        if (total >= obj.test.value) {
          break;
        }
      }
    }

    if (total == obj.test.value) {
      console.log("Added correct number of ".concat(obj.test.item, "'s to ").concat(obj.el));
      obj.completed = true;
    }
  }

  function testElement(obj) {
    var element = wrapper.querySelector(obj.el);
    if (!element) return;
    console.log("Added a ".concat(obj.test.item, " tag to the page"));
    obj.completed = true;
  }

  function testExternalStyles(obj) {
    var attr = obj.test.item;
    var mainStyle = styles[0];
    var check = mainStyle.cssRules[0].style[attr];
    var _iteratorNormalCompletion = true;
    var _didIteratorError = false;
    var _iteratorError = undefined;

    try {
      for (var _iterator = mainStyle.cssRules[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
        var item = _step.value;

        if (item.selectorText == obj.el) {
          if (attr == "color" || attr == "background") {
            if (getHEX(check) == obj.test.value.toLowerCase()) {
              obj.completed = true;
            }

            return;
          }

          if (check == obj.test.value) {
            obj.completed = true;
          }

          return;
        }
      }
    } catch (err) {
      _didIteratorError = true;
      _iteratorError = err;
    } finally {
      try {
        if (!_iteratorNormalCompletion && _iterator.return != null) {
          _iterator.return();
        }
      } finally {
        if (_didIteratorError) {
          throw _iteratorError;
        }
      }
    }
  }

  function testInlineStyles(obj) {
    var element = wrapper.querySelector(obj.el);
    if (!element) return;
    var attr = obj.test.item;

    if (attr == "color" || attr == "background") {
      console.log(element.style[attr]);
      console.log(obj.test.value.toLowerCase());

      if (getHEX(element.style[attr]) == obj.test.value.toLowerCase()) {
        console.log("Added correct ".concat(attr, " to ").concat(obj.el));
        obj.completed = true;
      }

      return;
    }

    console.log(element.style[attr]);

    if (element.style[attr] == obj.test.value) {
      console.log("Added correct ".concat(attr, " to ").concat(obj.el));
      obj.completed = true;
    }
  }

  function createInstructions() {
    instructionsBox = document.createElement("div");
    instructionsBox.classList.add("instructionsBox");
    body.append(instructionsBox);
  }

  function updateInstructions() {
    instructionsBox.innerHTML = "\n        <p><strong>Step ".concat(parseInt(currentIndex) + 1, " of ").concat(allTasks.length, "</strong></p>\n        <p>").concat(allTasks[currentIndex].desc, "</p>\n        <pre>").concat(allTasks[currentIndex].example, "</pre>\n        <div class=\"actions\">\n            <a href=\"#\" class=\"action -prev\">Prev</a>\n            <a href=\"#\" class=\"action -next\">Next</a>\n        </div>\n        <ol>\n            ").concat(allTasks[currentIndex].tasks.map(function (task) {
      return "<li title=\"".concat(task.hint, "\" class=\"").concat(task.completed ? "completed" : "todo", "\">\n        ").concat(task.instructions, "\n        .</li>");
    }).join(""), "\n        </ol>");
    addEventListeners();
  }

  function addEventListeners() {
    prev = document.querySelector(".action.-prev");
    next = document.querySelector(".action.-next");
    prev.addEventListener("click", prevTasks);
    next.addEventListener("click", nextTasks);
  }

  function prevTasks(e) {
    e.preventDefault();

    if (currentIndex <= 0) {
      currentIndex = 0;
    } else {
      currentIndex--;
    } // currentIndex = (currentIndex <= 0) ? 0 : currentIndex--;


    console.log(currentIndex);
    removeEventListeners();
    updateInstructions();
  }

  function nextTasks(e) {
    e.preventDefault();

    if (currentIndex >= allTasks.length - 1) {
      currentIndex = allTasks.length - 1;
    } else {
      currentIndex++;
    } // currentIndex = (currentIndex > allTasks.length - 1) ? allTasks.length - 1 : currentIndex++;


    console.log(currentIndex);
    removeEventListeners();
    updateInstructions();
  }

  function removeEventListeners() {
    prev.removeEventListener("click", prevTasks);
    next.removeEventListener("click", nextTasks);
  }

  function getHEX(color) {
    var _color$match = color.match(/\d+/g),
        _color$match2 = _slicedToArray(_color$match, 3),
        r = _color$match2[0],
        g = _color$match2[1],
        b = _color$match2[2];

    r = parseInt(r, 10);
    g = parseInt(g, 10);
    b = parseInt(b, 10);
    var red = r < 10 ? "0".concat(r) : r;
    var green = g < 10 ? "0".concat(g) : g;
    var blue = b < 10 ? "0".concat(b) : b;
    return "#".concat(red.toString(16)).concat(green.toString(16)).concat(blue.toString(16)).toLowerCase();
  }

  return {
    loadTests: loadTests,
    getVersion: getVersion
  };
}();